const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const ConnectionRequest = require('../models/connectionRequestModel');

async function cleanupOldRequests() {
  try {
    console.log('\n=== CLEANING UP OLD CONNECTION REQUESTS ===\n');
    
    // Find all declined and cancelled requests older than 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const oldDeclinedRequests = await ConnectionRequest.find({
      status: { $in: ['declined', 'cancelled'] },
      updatedAt: { $lt: sevenDaysAgo }
    });
    
    console.log(`📊 Found ${oldDeclinedRequests.length} old declined/cancelled requests (>7 days)`);
    
    if (oldDeclinedRequests.length === 0) {
      console.log('✅ No old requests to clean up!');
      process.exit(0);
    }
    
    console.log('\n🗑️ Deleting old requests...\n');
    
    const result = await ConnectionRequest.deleteMany({
      status: { $in: ['declined', 'cancelled'] },
      updatedAt: { $lt: sevenDaysAgo }
    });
    
    console.log(`✅ Deleted ${result.deletedCount} old connection requests`);
    console.log('\n💡 Users can now send fresh connection requests to these users');
    
    // Show remaining requests
    const remainingRequests = await ConnectionRequest.countDocuments({});
    console.log(`\n📊 Remaining connection requests: ${remainingRequests}`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

cleanupOldRequests();
