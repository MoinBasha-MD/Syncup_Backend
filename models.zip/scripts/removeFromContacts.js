const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function removeFromContacts() {
  try {
    const userIdentifier = process.argv[2];
    const contactIdentifier = process.argv[3];
    
    if (!userIdentifier || !contactIdentifier) {
      console.log('\n❌ Usage: node scripts/removeFromContacts.js <user> <contact>');
      console.log('\nExamples:');
      console.log('  node scripts/removeFromContacts.js user_1 user_3');
      console.log('  node scripts/removeFromContacts.js "User 1" "User 3"');
      console.log('\nThis will remove User 3 from User 1\'s device contacts array');
      process.exit(1);
    }
    
    console.log('\n=== REMOVING FROM DEVICE CONTACTS ===\n');
    
    // Find both users
    const [user, contactUser] = await Promise.all([
      User.findOne({
        $or: [
          { userId: userIdentifier },
          { name: { $regex: new RegExp(userIdentifier, 'i') } },
          { username: userIdentifier }
        ]
      }),
      User.findOne({
        $or: [
          { userId: contactIdentifier },
          { name: { $regex: new RegExp(contactIdentifier, 'i') } },
          { username: contactIdentifier }
        ]
      })
    ]);
    
    if (!user) {
      console.log(`❌ User not found: "${userIdentifier}"`);
      process.exit(1);
    }
    
    if (!contactUser) {
      console.log(`❌ Contact not found: "${contactIdentifier}"`);
      process.exit(1);
    }
    
    console.log(`👤 USER: ${user.name} (${user.userId})`);
    console.log(`📱 CONTACT: ${contactUser.name} (${contactUser.userId})`);
    
    // Check if contact exists in user's contacts array
    const contactIndex = user.contacts.findIndex(
      id => id.toString() === contactUser._id.toString()
    );
    
    if (contactIndex === -1) {
      console.log(`\n✅ ${contactUser.name} is NOT in ${user.name}'s device contacts`);
      console.log(`   Nothing to remove!`);
      process.exit(0);
    }
    
    console.log(`\n🔍 Found ${contactUser.name} in ${user.name}'s device contacts`);
    console.log(`   Removing from contacts array...`);
    
    // Remove contact
    user.contacts.splice(contactIndex, 1);
    await user.save();
    
    console.log(`\n✅ Successfully removed ${contactUser.name} from ${user.name}'s device contacts!`);
    console.log(`\n📊 RESULT:`);
    console.log(`   ${user.name}'s device contacts: ${user.contacts.length}`);
    console.log(`   ${contactUser.name} will now appear in global search for ${user.name}`);
    console.log(`   ${contactUser.name} will NOT appear in ${user.name}'s contact list`);
    
    console.log(`\n💡 Next steps:`);
    console.log(`   1. Refresh contacts in the app (Profile → Refresh Contacts)`);
    console.log(`   2. Try searching for "${contactUser.name}" in global search`);
    console.log(`   3. ${contactUser.name} should now appear in search results`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

removeFromContacts();
