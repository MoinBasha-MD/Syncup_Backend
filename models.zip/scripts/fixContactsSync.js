const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function fixContactsSync() {
  try {
    // Get userId from command line arguments
    const identifier = process.argv[2];
    
    if (!identifier) {
      console.log('\n❌ Usage: node scripts/fixContactsSync.js <userId or name>');
      console.log('\nExamples:');
      console.log('  node scripts/fixContactsSync.js user_1');
      console.log('  node scripts/fixContactsSync.js "User 1"');
      process.exit(1);
    }
    
    console.log('\n=== FIXING CONTACTS SYNC ISSUE ===\n');
    console.log(`🔍 Looking for user: "${identifier}"`);
    
    // Find the user
    const user = await User.findOne({
      $or: [
        { userId: identifier },
        { name: { $regex: new RegExp(identifier, 'i') } },
        { username: identifier }
      ]
    });
    
    if (!user) {
      console.log(`\n❌ User not found: "${identifier}"`);
      process.exit(1);
    }
    
    console.log(`\n✅ Found user: ${user.name} (${user.userId})`);
    console.log(`   Device contacts: ${user.contacts.length}`);
    
    if (user.contacts.length === 0) {
      console.log('\n✅ No device contacts to check');
      process.exit(0);
    }
    
    // Get all contact users
    const contactUsers = await User.find({ 
      _id: { $in: user.contacts } 
    }).select('_id userId name phoneNumber isPublic');
    
    console.log(`\n📱 DEVICE CONTACTS (${contactUsers.length} total):\n`);
    
    const publicContacts = [];
    const privateContacts = [];
    const orphanedContacts = [];
    
    // Check each contact
    for (const contactId of user.contacts) {
      const contact = contactUsers.find(c => c._id.toString() === contactId.toString());
      
      if (!contact) {
        orphanedContacts.push(contactId);
        console.log(`   ❌ ORPHANED: Contact ID ${contactId} - User not found in database!`);
      } else if (contact.isPublic) {
        publicContacts.push(contact);
        console.log(`   ✅ PUBLIC: ${contact.name} (${contact.userId}) - Will show in contact list`);
      } else {
        privateContacts.push(contact);
        console.log(`   🔒 PRIVATE: ${contact.name} (${contact.userId}) - Won't show in contact list`);
      }
    }
    
    // Summary
    console.log(`\n📊 SUMMARY:`);
    console.log(`   Total contacts in database: ${user.contacts.length}`);
    console.log(`   Public (visible): ${publicContacts.length}`);
    console.log(`   Private (hidden): ${privateContacts.length}`);
    console.log(`   Orphaned (deleted users): ${orphanedContacts.length}`);
    
    // Issues found
    if (privateContacts.length > 0 || orphanedContacts.length > 0) {
      console.log(`\n⚠️ ISSUES FOUND:\n`);
      
      if (privateContacts.length > 0) {
        console.log(`❌ ${privateContacts.length} contact(s) are PRIVATE and won't show in your contact list:`);
        privateContacts.forEach(c => {
          console.log(`   - ${c.name} (${c.userId})`);
        });
        console.log(`\n💡 These contacts are excluded from search because they're in your contacts array,`);
        console.log(`   but they don't appear in your contact list because they're private!`);
        console.log(`\n🔧 FIXES:`);
        console.log(`   Option 1: Make them public (they'll appear in contact list):`);
        privateContacts.forEach(c => {
          console.log(`      node scripts/setUserPublic.js "${c.userId}"`);
        });
        console.log(`\n   Option 2: Remove them from your contacts array (they'll appear in search):`);
        console.log(`      node scripts/removeFromContacts.js "${user.userId}" "${privateContacts.map(c => c.userId).join(' ')}"`);
      }
      
      if (orphanedContacts.length > 0) {
        console.log(`\n❌ ${orphanedContacts.length} orphaned contact(s) - users deleted from database:`);
        orphanedContacts.forEach(id => {
          console.log(`   - Contact ID: ${id}`);
        });
        console.log(`\n💡 These should be cleaned up from your contacts array`);
        console.log(`\n🔧 FIX: Run cleanup script`);
        console.log(`      node scripts/cleanupOrphanedContacts.js "${user.userId}"`);
      }
    } else {
      console.log(`\n✅ NO ISSUES FOUND!`);
      console.log(`   All contacts are public and should appear in your contact list.`);
    }
    
    console.log('\n' + '='.repeat(60) + '\n');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

fixContactsSync();
