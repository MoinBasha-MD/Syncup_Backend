const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');
const ConnectionRequest = require('../models/connectionRequestModel');

async function checkUserConnections() {
  try {
    // Get userId from command line arguments
    const identifier = process.argv[2];
    
    if (!identifier) {
      console.log('\n❌ Usage: node scripts/checkUserConnections.js <userId or name>');
      console.log('\nExamples:');
      console.log('  node scripts/checkUserConnections.js user_123');
      console.log('  node scripts/checkUserConnections.js "John Doe"');
      process.exit(1);
    }
    
    console.log(`\n=== CHECKING USER CONNECTIONS ===\n`);
    console.log(`🔍 Looking for user: "${identifier}"`);
    
    // Try to find user by userId or name
    const user = await User.findOne({
      $or: [
        { userId: identifier },
        { name: { $regex: new RegExp(identifier, 'i') } },
        { username: identifier }
      ]
    });
    
    if (!user) {
      console.log(`\n❌ User not found: "${identifier}"`);
      process.exit(1);
    }
    
    console.log(`\n✅ Found user: ${user.name} (${user.userId})`);
    console.log(`   Username: ${user.username || 'N/A'}`);
    console.log(`   Public: ${user.isPublic ? 'Yes' : 'No'}`);
    
    // Check app connections
    console.log(`\n📱 APP CONNECTIONS (${user.appConnections.length} total):`);
    
    if (user.appConnections.length > 0) {
      const statusCounts = {
        accepted: 0,
        pending: 0,
        declined: 0,
        cancelled: 0,
        other: 0
      };
      
      user.appConnections.forEach(conn => {
        if (statusCounts[conn.status] !== undefined) {
          statusCounts[conn.status]++;
        } else {
          statusCounts.other++;
        }
      });
      
      console.log(`   ✅ Accepted: ${statusCounts.accepted}`);
      console.log(`   ⏳ Pending: ${statusCounts.pending}`);
      console.log(`   ❌ Declined: ${statusCounts.declined}`);
      console.log(`   🚫 Cancelled: ${statusCounts.cancelled}`);
      if (statusCounts.other > 0) {
        console.log(`   ❓ Other: ${statusCounts.other}`);
      }
      
      console.log('\n   Detailed list:');
      for (const conn of user.appConnections) {
        const connectedUser = await User.findOne({ userId: conn.userId }, 'name username');
        const statusEmoji = {
          accepted: '✅',
          pending: '⏳',
          declined: '❌',
          cancelled: '🚫'
        }[conn.status] || '❓';
        
        console.log(`   ${statusEmoji} ${connectedUser?.name || 'Unknown'} (${conn.userId}) - ${conn.status}`);
      }
    } else {
      console.log('   No app connections');
    }
    
    // Check device contacts
    console.log(`\n📞 DEVICE CONTACTS (${user.contacts.length} total):`);
    if (user.contacts.length > 0) {
      const contactUsers = await User.find({ 
        _id: { $in: user.contacts } 
      }, 'userId name username');
      
      contactUsers.forEach(contact => {
        console.log(`   📱 ${contact.name} (${contact.userId})`);
      });
    } else {
      console.log('   No device contacts');
    }
    
    // Check connection requests
    const [outgoingRequests, incomingRequests] = await Promise.all([
      ConnectionRequest.find({ fromUserId: user.userId }),
      ConnectionRequest.find({ toUserId: user.userId })
    ]);
    
    console.log(`\n📤 OUTGOING REQUESTS (${outgoingRequests.length} total):`);
    if (outgoingRequests.length > 0) {
      for (const req of outgoingRequests) {
        const toUser = await User.findOne({ userId: req.toUserId }, 'name username');
        const statusEmoji = {
          pending: '⏳',
          accepted: '✅',
          declined: '❌',
          cancelled: '🚫'
        }[req.status] || '❓';
        
        console.log(`   ${statusEmoji} To: ${toUser?.name || 'Unknown'} (${req.toUserId}) - ${req.status}`);
      }
    } else {
      console.log('   No outgoing requests');
    }
    
    console.log(`\n📥 INCOMING REQUESTS (${incomingRequests.length} total):`);
    if (incomingRequests.length > 0) {
      for (const req of incomingRequests) {
        const fromUser = await User.findOne({ userId: req.fromUserId }, 'name username');
        const statusEmoji = {
          pending: '⏳',
          accepted: '✅',
          declined: '❌',
          cancelled: '🚫'
        }[req.status] || '❓';
        
        console.log(`   ${statusEmoji} From: ${fromUser?.name || 'Unknown'} (${req.fromUserId}) - ${req.status}`);
      }
    } else {
      console.log('   No incoming requests');
    }
    
    // Summary
    console.log(`\n📊 SUMMARY:`);
    console.log(`   Total app connections: ${user.appConnections.length}`);
    console.log(`   Active connections: ${user.appConnections.filter(c => c.status === 'accepted').length}`);
    console.log(`   Device contacts: ${user.contacts.length}`);
    console.log(`   Outgoing requests: ${outgoingRequests.length}`);
    console.log(`   Incoming requests: ${incomingRequests.length}`);
    console.log(`   Searchable: ${user.isPublic ? 'Yes ✅' : 'No ❌'}`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

checkUserConnections();
