const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function cleanupOrphanedContacts() {
  try {
    const identifier = process.argv[2];
    
    if (!identifier) {
      console.log('\n❌ Usage: node scripts/cleanupOrphanedContacts.js <userId or name>');
      console.log('\nExamples:');
      console.log('  node scripts/cleanupOrphanedContacts.js user_1');
      console.log('  node scripts/cleanupOrphanedContacts.js "User 1"');
      console.log('\nThis will remove orphaned contacts (deleted users) from the contacts array');
      process.exit(1);
    }
    
    console.log('\n=== CLEANING UP ORPHANED CONTACTS ===\n');
    console.log(`🔍 Looking for user: "${identifier}"`);
    
    // Find the user
    const user = await User.findOne({
      $or: [
        { userId: identifier },
        { name: { $regex: new RegExp(identifier, 'i') } },
        { username: identifier }
      ]
    });
    
    if (!user) {
      console.log(`\n❌ User not found: "${identifier}"`);
      process.exit(1);
    }
    
    console.log(`\n✅ Found user: ${user.name} (${user.userId})`);
    console.log(`   Current device contacts: ${user.contacts.length}`);
    
    if (user.contacts.length === 0) {
      console.log('\n✅ No contacts to clean up');
      process.exit(0);
    }
    
    // Check which contacts still exist
    const validContacts = [];
    const orphanedContacts = [];
    
    for (const contactId of user.contacts) {
      const contactExists = await User.findById(contactId);
      if (contactExists) {
        validContacts.push(contactId);
      } else {
        orphanedContacts.push(contactId);
      }
    }
    
    console.log(`\n📊 ANALYSIS:`);
    console.log(`   Valid contacts: ${validContacts.length}`);
    console.log(`   Orphaned contacts: ${orphanedContacts.length}`);
    
    if (orphanedContacts.length === 0) {
      console.log(`\n✅ No orphaned contacts found!`);
      console.log(`   All contacts are valid.`);
      process.exit(0);
    }
    
    console.log(`\n🗑️ Removing ${orphanedContacts.length} orphaned contact(s)...`);
    orphanedContacts.forEach(id => {
      console.log(`   - Contact ID: ${id}`);
    });
    
    // Update user with only valid contacts
    user.contacts = validContacts;
    await user.save();
    
    console.log(`\n✅ Cleanup complete!`);
    console.log(`   Removed: ${orphanedContacts.length} orphaned contacts`);
    console.log(`   Remaining: ${validContacts.length} valid contacts`);
    
    console.log(`\n💡 Next steps:`);
    console.log(`   1. Refresh contacts in the app (Profile → Refresh Contacts)`);
    console.log(`   2. Contact list should now be accurate`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

cleanupOrphanedContacts();
