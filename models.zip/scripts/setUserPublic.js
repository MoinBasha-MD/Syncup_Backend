const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function setUserPublic() {
  try {
    // Get userId or name from command line arguments
    const identifier = process.argv[2];
    
    if (!identifier) {
      console.log('\n❌ Usage: node scripts/setUserPublic.js <userId or name>');
      console.log('\nExamples:');
      console.log('  node scripts/setUserPublic.js user_123');
      console.log('  node scripts/setUserPublic.js "John Doe"');
      process.exit(1);
    }
    
    console.log(`\n=== SETTING USER TO PUBLIC ===\n`);
    console.log(`🔍 Looking for user: "${identifier}"`);
    
    // Try to find user by userId or name
    const user = await User.findOne({
      $or: [
        { userId: identifier },
        { name: { $regex: new RegExp(identifier, 'i') } },
        { username: identifier }
      ]
    });
    
    if (!user) {
      console.log(`\n❌ User not found: "${identifier}"`);
      console.log('\n💡 Available users:');
      const allUsers = await User.find({}).select('userId name username').limit(10);
      allUsers.forEach(u => {
        console.log(`   - ${u.name} (${u.userId}) - Username: ${u.username || 'N/A'}`);
      });
      process.exit(1);
    }
    
    console.log(`\n✅ Found user: ${user.name} (${user.userId})`);
    console.log(`   Current status: ${user.isPublic ? 'Public' : 'Private'}`);
    
    if (user.isPublic) {
      console.log('\n✅ User is already public!');
      process.exit(0);
    }
    
    // Update user to public
    user.isPublic = true;
    await user.save();
    
    console.log(`\n✅ User "${user.name}" is now PUBLIC and searchable!`);
    console.log(`   - userId: ${user.userId}`);
    console.log(`   - username: ${user.username || 'N/A'}`);
    console.log(`   - isPublic: ${user.isPublic}`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

setUserPublic();
