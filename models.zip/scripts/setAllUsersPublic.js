const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function setAllUsersPublic() {
  try {
    console.log('\n=== SETTING ALL USERS TO PUBLIC ===\n');
    
    // Get all users that are currently private
    const privateUsers = await User.find({ 
      $or: [
        { isPublic: false },
        { isPublic: { $exists: false } }
      ]
    }).select('userId name username isPublic');
    
    console.log(`📊 Found ${privateUsers.length} private users`);
    
    if (privateUsers.length === 0) {
      console.log('✅ All users are already public!');
      process.exit(0);
    }
    
    console.log('\n🔄 Updating users to public...\n');
    
    // Update all users to public
    const result = await User.updateMany(
      { 
        $or: [
          { isPublic: false },
          { isPublic: { $exists: false } }
        ]
      },
      { 
        $set: { isPublic: true } 
      }
    );
    
    console.log(`✅ Updated ${result.modifiedCount} users to public`);
    
    // Verify the update
    const publicCount = await User.countDocuments({ isPublic: true });
    const totalCount = await User.countDocuments({});
    
    console.log(`\n📈 Final Statistics:`);
    console.log(`   Total users: ${totalCount}`);
    console.log(`   Public users: ${publicCount}`);
    console.log(`   Private users: ${totalCount - publicCount}`);
    
    console.log('\n✅ All users are now searchable in global search!');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

setAllUsersPublic();
