const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function checkPublicUsers() {
  try {
    console.log('\n=== CHECKING PUBLIC USERS ===\n');
    
    // Get all users
    const allUsers = await User.find({}).select('userId name username isPublic');
    console.log(`📊 Total users in database: ${allUsers.length}`);
    
    // Count public vs private
    const publicUsers = allUsers.filter(u => u.isPublic === true);
    const privateUsers = allUsers.filter(u => u.isPublic === false || u.isPublic === undefined);
    
    console.log(`\n📈 Statistics:`);
    console.log(`   ✅ Public users: ${publicUsers.length}`);
    console.log(`   🔒 Private users: ${privateUsers.length}`);
    
    if (publicUsers.length > 0) {
      console.log(`\n✅ PUBLIC USERS (searchable):`);
      publicUsers.forEach(user => {
        console.log(`   - ${user.name} (${user.userId}) - Username: ${user.username || 'N/A'}`);
      });
    }
    
    if (privateUsers.length > 0) {
      console.log(`\n🔒 PRIVATE USERS (not searchable):`);
      privateUsers.forEach(user => {
        console.log(`   - ${user.name} (${user.userId}) - Username: ${user.username || 'N/A'}`);
      });
    }
    
    console.log(`\n💡 To make users searchable, they need to:`);
    console.log(`   1. Open the app`);
    console.log(`   2. Go to Profile → Privacy Settings`);
    console.log(`   3. Enable "Public Profile" toggle`);
    
    console.log(`\n🔧 Or run: node scripts/setAllUsersPublic.js (to make all users public)`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

checkPublicUsers();
