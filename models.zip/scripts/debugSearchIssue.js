const mongoose = require('mongoose');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));

const User = require('../models/userModel');

async function debugSearchIssue() {
  try {
    const searcherIdentifier = process.argv[2];
    const targetIdentifier = process.argv[3];
    
    if (!searcherIdentifier || !targetIdentifier) {
      console.log('\n❌ Usage: node scripts/debugSearchIssue.js <searcher> <target>');
      console.log('\nExample:');
      console.log('  node scripts/debugSearchIssue.js "User 1" "User 3"');
      console.log('  node scripts/debugSearchIssue.js user_1 user_3');
      console.log('\nThis will check why User 1 cannot find User 3 in search');
      process.exit(1);
    }
    
    console.log('\n=== DEBUGGING SEARCH ISSUE ===\n');
    
    // Find both users
    const [searcher, target] = await Promise.all([
      User.findOne({
        $or: [
          { userId: searcherIdentifier },
          { name: { $regex: new RegExp(searcherIdentifier, 'i') } },
          { username: searcherIdentifier }
        ]
      }),
      User.findOne({
        $or: [
          { userId: targetIdentifier },
          { name: { $regex: new RegExp(targetIdentifier, 'i') } },
          { username: targetIdentifier }
        ]
      })
    ]);
    
    if (!searcher) {
      console.log(`❌ Searcher not found: "${searcherIdentifier}"`);
      process.exit(1);
    }
    
    if (!target) {
      console.log(`❌ Target not found: "${targetIdentifier}"`);
      process.exit(1);
    }
    
    console.log(`👤 SEARCHER: ${searcher.name} (${searcher.userId})`);
    console.log(`🎯 TARGET: ${target.name} (${target.userId})`);
    console.log('\n' + '='.repeat(60) + '\n');
    
    // Check 1: Is target public?
    console.log('CHECK 1: Is target user public?');
    if (target.isPublic) {
      console.log(`   ✅ YES - Target is public (isPublic: true)`);
    } else {
      console.log(`   ❌ NO - Target is private (isPublic: false)`);
      console.log(`   💡 FIX: Target user needs to enable "Public Profile" in app settings`);
      console.log(`   💡 OR run: node scripts/setUserPublic.js "${target.userId}"`);
    }
    
    // Check 2: Are they already connected?
    console.log('\nCHECK 2: Are they already connected?');
    const searcherHasTarget = searcher.appConnections.some(
      conn => conn.userId === target.userId && conn.status === 'accepted'
    );
    const targetHasSearcher = target.appConnections.some(
      conn => conn.userId === searcher.userId && conn.status === 'accepted'
    );
    
    if (searcherHasTarget || targetHasSearcher) {
      console.log(`   ❌ YES - They are already connected`);
      console.log(`   💡 Already connected users are excluded from search`);
      console.log(`   💡 This is by design to show only new connection suggestions`);
      
      if (searcherHasTarget) {
        const conn = searcher.appConnections.find(c => c.userId === target.userId);
        console.log(`   📱 Searcher -> Target: ${conn.status}`);
      }
      if (targetHasSearcher) {
        const conn = target.appConnections.find(c => c.userId === searcher.userId);
        console.log(`   📱 Target -> Searcher: ${conn.status}`);
      }
    } else {
      console.log(`   ✅ NO - They are not connected`);
    }
    
    // Check 3: Are they in device contacts?
    console.log('\nCHECK 3: Are they in device contacts?');
    const contactUsers = await User.find({ 
      _id: { $in: searcher.contacts } 
    }, 'userId name');
    const isInContacts = contactUsers.some(u => u.userId === target.userId);
    
    if (isInContacts) {
      console.log(`   ❌ YES - Target is in searcher's device contacts`);
      console.log(`   💡 Device contacts are excluded from search`);
      console.log(`   💡 This is by design - they're already in your contacts`);
    } else {
      console.log(`   ✅ NO - Not in device contacts`);
    }
    
    // Check 4: Check old connection statuses
    console.log('\nCHECK 4: Check connection history');
    const allSearcherConnections = searcher.appConnections.filter(
      conn => conn.userId === target.userId
    );
    
    if (allSearcherConnections.length > 0) {
      console.log(`   ⚠️ Found ${allSearcherConnections.length} connection record(s):`);
      allSearcherConnections.forEach(conn => {
        console.log(`      - Status: ${conn.status}`);
        console.log(`        Added: ${conn.addedAt || 'N/A'}`);
      });
      
      const hasNonAccepted = allSearcherConnections.some(c => c.status !== 'accepted');
      if (hasNonAccepted) {
        console.log(`   💡 Old declined/cancelled connections should not block search`);
        console.log(`   💡 Only "accepted" connections are excluded`);
      }
    } else {
      console.log(`   ✅ No connection history found`);
    }
    
    // Final verdict
    console.log('\n' + '='.repeat(60));
    console.log('\n🎯 VERDICT:\n');
    
    const issues = [];
    const fixes = [];
    
    if (!target.isPublic) {
      issues.push('❌ Target user is not public');
      fixes.push(`   1. Target enables "Public Profile" in app`);
      fixes.push(`      OR run: node scripts/setUserPublic.js "${target.userId}"`);
    }
    
    if (searcherHasTarget || targetHasSearcher) {
      issues.push('❌ Users are already connected (accepted status)');
      fixes.push(`   2. This is by design - connected users don't appear in search`);
    }
    
    if (isInContacts) {
      issues.push('❌ Target is in searcher\'s device contacts');
      fixes.push(`   3. This is by design - device contacts don't appear in search`);
    }
    
    if (issues.length === 0) {
      console.log('✅ NO ISSUES FOUND!');
      console.log(`\n${target.name} SHOULD appear in ${searcher.name}'s search results.`);
      console.log('\n💡 If still not appearing:');
      console.log('   - Restart backend server');
      console.log('   - Clear app cache and restart');
      console.log('   - Check backend logs for errors');
    } else {
      console.log('ISSUES FOUND:\n');
      issues.forEach(issue => console.log(issue));
      console.log('\nFIXES:\n');
      fixes.forEach(fix => console.log(fix));
    }
    
    console.log('\n' + '='.repeat(60) + '\n');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

debugSearchIssue();
