const express = require('express');
const router = express.Router();
const storyController = require('../controllers/storyController');
const { protect } = require('../middleware/authMiddleware');

// Apply auth middleware to all story routes
router.use(protect);

// POST /api/stories - Create a new story
router.post('/', storyController.createStory);

// GET /api/stories/contacts - Get active stories from user's contacts
router.get('/contacts', storyController.getContactsStories);

// POST /api/stories/contacts - Get active stories with contacts array from frontend
router.post('/contacts', storyController.getContactsStories);

// POST /api/stories/seen - Mark story as seen
router.post('/seen', storyController.markStorySeen);

// POST /api/stories/:id/like - Toggle like on a story
router.post('/:id/like', storyController.toggleStoryLike);

// GET /api/stories/:id/likes - Get likes for a story
router.get('/:id/likes', storyController.getStoryLikes);

// POST /api/stories/:id/view - Track story view
router.post('/:id/view', storyController.trackStoryView);

// GET /api/stories/:id/views - Get views for a story
router.get('/:id/views', storyController.getStoryViews);

// DELETE /api/stories/:id - Delete a story
router.delete('/:id', storyController.deleteStory);

// POST /api/stories/cleanup - Clean up expired and duplicate stories
router.post('/cleanup', storyController.cleanupStories);

module.exports = router;
