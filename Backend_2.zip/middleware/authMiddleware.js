const jwt = require('jsonwebtoken');
const User = require('../models/userModel');
const { UnauthorizedError } = require('../utils/errorClasses');

// Protect routes middleware
const protect = async (req, res, next) => {
  try {
    let token;

    // Check for token in Authorization header
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      // Extract token from Bearer header
      token = req.headers.authorization.split(' ')[1];

      if (!token) {
        throw new UnauthorizedError('No token provided');
      }

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Get user from the token (exclude password)
      const user = await User.findById(decoded.id).select('-password');
      
      if (!user) {
        throw new UnauthorizedError('User not found - token may be invalid');
      }

      // Check if user account is active (if you have such field)
      if (user.isActive === false) {
        throw new UnauthorizedError('Account is deactivated');
      }
      
      // Attach user to request object
      req.user = user;
      next();
    } else {
      throw new UnauthorizedError('Not authorized, no token provided');
    }
  } catch (error) {
    // Handle JWT specific errors
    if (error.name === 'JsonWebTokenError') {
      return next(new UnauthorizedError('Invalid token'));
    }
    if (error.name === 'TokenExpiredError') {
      return next(new UnauthorizedError('Token expired'));
    }
    
    // Pass other errors to error handler
    next(error);
  }
};

// Optional: Admin role check middleware
const requireAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    next(new UnauthorizedError('Admin access required'));
  }
};

// Optional: Check if user owns resource or is admin
const checkOwnership = (req, res, next) => {
  const resourceUserId = req.params.userId || req.body.userId;
  
  if (req.user.userId === resourceUserId || req.user.role === 'admin') {
    next();
  } else {
    next(new UnauthorizedError('Access denied - insufficient permissions'));
  }
};

module.exports = { 
  protect,
  requireAdmin,
  checkOwnership
};
