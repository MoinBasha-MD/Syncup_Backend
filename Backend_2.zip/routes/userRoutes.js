const express = require('express');
const router = express.Router();
const { 
  registerUser, 
  loginUser, 
  getUserProfile,
  updateUserProfile,
  updateUserStatus,
  getRegisteredUsers,
  getUserByUserId,
  getUserContacts,
  getUserByPhone
} = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');

// Public routes
router.post('/', registerUser);
router.post('/login', loginUser);
router.get('/registered', getRegisteredUsers);

// Get user by userId (UUID) via query parameter
router.get('/', protect, getUserByUserId);

// Protected routes
router.route('/profile')
  .get(protect, getUserProfile)
  .put(protect, updateUserProfile);

// Status routes
router.route('/status')
  .put(protect, updateUserStatus);

// Contacts routes
router.route('/contacts')
  .get(protect, getUserContacts);

// Phone lookup route
router.route('/phone/:phoneNumber')
  .get(protect, getUserByPhone);

module.exports = router;
