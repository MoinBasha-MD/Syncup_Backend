const express = require('express');
const router = express.Router();
const { uploadProfileImage, uploadMiddleware } = require('../controllers/uploadController');
const { protect } = require('../middleware/authMiddleware');

// Route for uploading profile image
router.post('/profile-image', protect, uploadMiddleware, uploadProfileImage);

module.exports = router;
