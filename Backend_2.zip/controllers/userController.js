const User = require('../models/userModel');
const StatusHistory = require('../models/statusHistoryModel');
const { broadcastStatusUpdate } = require('../socketManager');

// @desc    Register a new user
// @route   POST /api/users
// @access  Public
const registerUser = async (req, res) => {
  try {
    const { name, phoneNumber, email, password } = req.body;

    // Check if user already exists with this email or phone
    const userExistsWithEmail = await User.findOne({ email });
    if (userExistsWithEmail) {
      return res.status(400).json({ message: 'User with this email already exists' });
    }

    const userExistsWithPhone = await User.findOne({ phoneNumber });
    if (userExistsWithPhone) {
      return res.status(400).json({ message: 'User with this phone number already exists' });
    }

    // Create user
    const user = await User.create({
      name,
      phoneNumber,
      email,
      password,
      status: 'available',
      customStatus: '',
      statusUntil: null
    });

    if (user) {
      res.status(201).json({
        _id: user._id,
        userId: user.userId,
        name: user.name,
        phoneNumber: user.phoneNumber,
        email: user.email,
        status: user.status,
        customStatus: user.customStatus,
        statusUntil: user.statusUntil,
        token: user.getSignedJwtToken(),
      });
    } else {
      res.status(400).json({ message: 'Invalid user data' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Auth user & get token
// @route   POST /api/users/login
// @access  Public
const loginUser = async (req, res) => {
  try {
    const { phoneNumber, password } = req.body;

    // Check for user with phone number
    const user = await User.findOne({ phoneNumber }).select('+password');

    if (!user) {
      return res.status(401).json({ message: 'Invalid phone number or password' });
    }

    // Check if password matches
    const isMatch = await user.matchPassword(password);

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid phone number or password' });
    }

    // Check if status timer has expired
    if (user.statusUntil && new Date() > new Date(user.statusUntil)) {
      user.status = 'available';
      user.customStatus = '';
      user.statusUntil = null;
      await user.save();
    }

    res.json({
      _id: user._id,
      userId: user.userId,
      name: user.name,
      phoneNumber: user.phoneNumber,
      email: user.email,
      status: user.status,
      customStatus: user.customStatus,
      statusUntil: user.statusUntil,
      token: user.getSignedJwtToken(),
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      // Check if status timer has expired
      if (user.statusUntil && new Date() > new Date(user.statusUntil)) {
        user.status = 'available';
        user.customStatus = '';
        user.statusUntil = null;
        await user.save();
      }

      res.json({
        _id: user._id,
        userId: user.userId,
        name: user.name,
        phoneNumber: user.phoneNumber,
        email: user.email,
        status: user.status,
        customStatus: user.customStatus,
        statusUntil: user.statusUntil
      });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
// @desc    Update user status
// @route   PUT /api/users/status
// @access  Private
const updateUserStatus = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      const { status, customStatus, duration } = req.body;
      
      // Validate status
      const validStatuses = [
        // Basic statuses
        'available', 'busy', 'away', 'dnd',
        // Location-based statuses
        'at_work', 'at_home', 'at_school', 'at_college', 'at_hospital', 'at_mosque', 'at_temple', 'at_theatre', 'at_emergency',
        // Activity-based statuses
        'meeting', 'driving', 'commuting', 'working_out', 'eating', 'sleeping', 'studying', 'in_a_meeting',
        // Custom status
        'custom', 'extended', 'pause'
      ];
      
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ message: 'Invalid status type' });
      }
      
      // Store previous status for history tracking
      const previousStatus = user.status;
      const previousCustomStatus = user.customStatus || '';
      const statusChangeTime = new Date();
      
      // Update status fields
      user.status = status;
      
      // Update custom status if provided and status is custom
      if (status === 'custom' && customStatus) {
        user.customStatus = customStatus;
      } else if (status !== 'custom') {
        user.customStatus = '';
      }
      
      // Set status expiration if duration provided (in minutes)
      let expirationTime = null;
      if (duration && duration > 0) {
        expirationTime = new Date();
        expirationTime.setMinutes(expirationTime.getMinutes() + duration);
        user.statusUntil = expirationTime;
      } else {
        user.statusUntil = null; // No expiration
      }
      
      const updatedUser = await user.save();
      
      // Create status history entry if status has changed
      if (previousStatus !== status || 
          (status === 'custom' && previousCustomStatus !== user.customStatus)) {
        
        // Create a new status history entry
        await StatusHistory.create({
          user: user._id,
          userId: user.userId,
          status: status,
          customStatus: status === 'custom' ? user.customStatus : '',
          startTime: statusChangeTime,
          endTime: expirationTime || null,
          duration: duration || 0,
          isActive: true,
          completed: false,
          endedAt: statusChangeTime.toISOString()
        });
        
        console.log(`Status history entry created for user ${user._id}`);
      }
      
      // Broadcast status update to all relevant users via WebSocket
      broadcastStatusUpdate(updatedUser._id.toString(), {
        status: updatedUser.status,
        customStatus: updatedUser.customStatus,
        statusUntil: updatedUser.statusUntil
      });
      
      console.log(`Status update broadcast for user ${updatedUser._id}`);
      
      res.json({
        _id: updatedUser._id,
        userId: updatedUser.userId,
        name: updatedUser.name,
        phoneNumber: updatedUser.phoneNumber,
        email: updatedUser.email,
        status: updatedUser.status,
        customStatus: updatedUser.customStatus,
        statusUntil: updatedUser.statusUntil
      });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

const updateUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      user.name = req.body.name || user.name;
      user.email = req.body.email || user.email;
      
      // Only update phone number if provided and different
      if (req.body.phoneNumber && req.body.phoneNumber !== user.phoneNumber) {
        // Check if phone number is already in use
        const phoneExists = await User.findOne({ phoneNumber: req.body.phoneNumber });
        if (phoneExists) {
          return res.status(400).json({ message: 'Phone number already in use' });
        }
        user.phoneNumber = req.body.phoneNumber;
      }

      // Update password if provided
      if (req.body.password) {
        user.password = req.body.password;
      }

      const updatedUser = await user.save();

      res.json({
        _id: updatedUser._id,
        userId: updatedUser.userId,
        name: updatedUser.name,
        phoneNumber: updatedUser.phoneNumber,
        email: updatedUser.email,
        status: updatedUser.status,
        customStatus: updatedUser.customStatus,
        statusUntil: updatedUser.statusUntil,
        token: updatedUser.getSignedJwtToken(),
      });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get all registered users (minimal data for contact sync)
// @route   GET /api/users/registered
// @access  Public
const getRegisteredUsers = async (req, res) => {
  try {
    // Get all users but include profileImage for contact display in HomeTab
    const users = await User.find({}).select('_id userId name phoneNumber profileImage status customStatus statusUntil');
    
    console.log(`Fetching ${users.length} registered users with profile images`);
    
    // Format the response to match what the frontend expects
    const formattedUsers = users.map(user => {
      // Check if status timer has expired
      let currentStatus = user.status;
      let currentCustomStatus = user.customStatus;
      if (user.statusUntil && new Date() > new Date(user.statusUntil)) {
        currentStatus = 'available';
        currentCustomStatus = '';
      }
      
      return {
        id: user._id,
        userId: user.userId,
        fullName: user.name,
        phoneNumber: user.phoneNumber,
        profileImage: user.profileImage, // Include profile image for HomeTab display
        status: currentStatus,
        customStatus: currentCustomStatus,
        statusUntil: user.statusUntil
      };
    });
    
    console.log(`Returning ${formattedUsers.length} users with profile image data`);
    res.json({ users: formattedUsers });
  } catch (error) {
    console.error('Error fetching registered users:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get user by userId (UUID)
// @route   GET /api/users?userid=:userId
// @access  Private
const getUserByUserId = async (req, res) => {
  try {
    const { userid } = req.query;

    if (!userid) {
      return res.status(400).json({ 
        success: false,
        message: 'User ID is required' 
      });
    }

    console.log(`Getting user data for userId: ${userid}`);

    // Find user by UUID (userId field)
    const user = await User.findOne({ userId: userid });

    if (!user) {
      return res.status(404).json({ 
        success: false,
        message: 'User not found' 
      });
    }

    // Return user data without sensitive information
    res.json({
      success: true,
      data: {
        _id: user._id,
        userId: user.userId,
        name: user.name,
        phoneNumber: user.phoneNumber,
        email: user.email,
        status: user.status,
        customStatus: user.customStatus,
        statusUntil: user.statusUntil,
        profileImage: user.profileImage
      }
    });
  } catch (error) {
    console.error('Error getting user by userId:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// @desc    Get all contacts for the authenticated user
// @route   GET /api/users/contacts
// @access  Private
const getUserContacts = async (req, res) => {
  try {
    // Get the authenticated user
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ 
        success: false,
        message: 'User not found' 
      });
    }

    console.log(`Getting contacts for user ${user._id}, contacts count: ${user.contacts.length}`);
    
    // If user has no contacts, return empty array
    if (!user.contacts || user.contacts.length === 0) {
      return res.status(200).json({
        success: true,
        data: []
      });
    }

    // Get contacts with their status information
    const contacts = await User.find(
      { _id: { $in: user.contacts } },
      '_id userId name phoneNumber email profileImage status customStatus statusUntil'
    );

    console.log(`Found ${contacts.length} contacts`);
    
    res.status(200).json({
      success: true,
      data: contacts
    });
  } catch (error) {
    console.error('Error getting user contacts:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// @desc    Get user by phone number
// @route   GET /api/users/phone/:phoneNumber
// @access  Private
const getUserByPhone = async (req, res) => {
  try {
    const { phoneNumber } = req.params;

    if (!phoneNumber) {
      return res.status(400).json({ 
        success: false,
        message: 'Phone number is required' 
      });
    }

    console.log(`Getting user data for phone: ${phoneNumber}`);

    // Find user by phone number
    const user = await User.findOne({ phoneNumber: phoneNumber });

    if (!user) {
      return res.status(404).json({ 
        success: false,
        message: 'User not found' 
      });
    }

    // Check if status timer has expired
    if (user.statusUntil && new Date() > new Date(user.statusUntil)) {
      user.status = 'available';
      user.customStatus = '';
      user.statusUntil = null;
      await user.save();
    }

    // Return user data without sensitive information
    res.json({
      success: true,
      data: {
        _id: user._id,
        userId: user.userId,
        name: user.name,
        phoneNumber: user.phoneNumber,
        email: user.email,
        status: user.status,
        customStatus: user.customStatus,
        statusUntil: user.statusUntil,
        profileImage: user.profileImage
      }
    });
  } catch (error) {
    console.error('Error getting user by phone number:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

module.exports = {
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  updateUserStatus,
  getRegisteredUsers,
  getUserByUserId,
  getUserContacts,
  getUserByPhone
};
