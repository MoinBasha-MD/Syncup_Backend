const Message = require('../models/Message');
const User = require('../models/userModel');
const { broadcastToUser } = require('../socketManager');

// Send a message
const sendMessage = async (req, res) => {
  try {
    const { receiverId, message, messageType = 'text' } = req.body;
    const senderId = req.user.userId;

    // Validate required fields
    if (!receiverId || !message) {
      return res.status(400).json({
        success: false,
        message: 'Receiver ID and message are required'
      });
    }

    // Create new message
    const newMessage = new Message({
      senderId,
      receiverId,
      message,
      messageType,
      timestamp: new Date(),
      status: 'sent'
    });

    // Save message to database
    const savedMessage = await newMessage.save();

    // Broadcast message to receiver via WebSocket
    // CRITICAL: Get receiver's MongoDB ObjectId for socket broadcasting
    try {
      const receiverUser = await User.findOne({ userId: receiverId }).select('_id');
      if (receiverUser) {
        const receiverObjectId = receiverUser._id.toString();
        broadcastToUser(receiverObjectId, 'message:new', {
          _id: savedMessage._id,
          senderId: savedMessage.senderId,
          receiverId: savedMessage.receiverId,
          message: savedMessage.message,
          messageType: savedMessage.messageType,
          timestamp: savedMessage.timestamp,
          status: 'delivered'
        });
      }
    } catch (broadcastError) {
      console.error('Error broadcasting message:', broadcastError);
    }

    // Update message status to delivered
    savedMessage.status = 'delivered';
    await savedMessage.save();

    res.status(201).json({
      success: true,
      data: savedMessage,
      message: 'Message sent successfully'
    });

  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send message',
      error: error.message
    });
  }
};

// Get chat history with pagination
const getChatHistory = async (req, res) => {
  try {
    const { contactId } = req.params;
    const userId = req.user.userId;
    const { page = 1, limit = 50 } = req.query;

    const skip = (page - 1) * limit;

    // Get messages between current user and contact
    const messages = await Message.getConversation(userId, contactId, skip, parseInt(limit));

    res.status(200).json({
      success: true,
      data: messages,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        hasMore: messages.length === parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Error fetching chat history:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch chat history',
      error: error.message
    });
  }
};

// Mark messages as read
const markMessagesAsRead = async (req, res) => {
  try {
    const { contactId } = req.body;
    const userId = req.user.userId;

    if (!contactId) {
      return res.status(400).json({
        success: false,
        message: 'Contact ID is required'
      });
    }

    // Mark all unread messages from contact as read
    const result = await Message.markAsRead(contactId, userId);

    // Broadcast read receipt to sender
    // CRITICAL: Get sender's MongoDB ObjectId for socket broadcasting
    try {
      const senderUser = await User.findOne({ userId: contactId }).select('_id');
      if (senderUser) {
        const senderObjectId = senderUser._id.toString();
        broadcastToUser(senderObjectId, 'message:read', {
          readBy: userId,
          timestamp: new Date()
        });
      }
    } catch (broadcastError) {
      console.error('Error broadcasting read receipt:', broadcastError);
    }

    res.status(200).json({
      success: true,
      data: { modifiedCount: result.modifiedCount },
      message: 'Messages marked as read'
    });

  } catch (error) {
    console.error('Error marking messages as read:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to mark messages as read',
      error: error.message
    });
  }
};

// Get unread message count for a specific contact
const getUnreadCount = async (req, res) => {
  try {
    const { contactId } = req.params;
    const userId = req.user.userId;

    const count = await Message.getUnreadCount(contactId, userId);

    res.status(200).json({
      success: true,
      data: { count },
      message: 'Unread count retrieved successfully'
    });

  } catch (error) {
    console.error('Error getting unread count:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get unread count',
      error: error.message
    });
  }
};

// Get all unread message counts
const getAllUnreadCounts = async (req, res) => {
  try {
    const userId = req.user.userId;

    const counts = await Message.getAllUnreadCounts(userId);

    res.status(200).json({
      success: true,
      data: counts,
      message: 'All unread counts retrieved successfully'
    });

  } catch (error) {
    console.error('Error getting all unread counts:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get unread counts',
      error: error.message
    });
  }
};

// Delete a message
const deleteMessage = async (req, res) => {
  try {
    const { messageId } = req.params;
    const userId = req.user.userId;

    // Find the message and verify ownership
    const message = await Message.findById(messageId);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found'
      });
    }

    // Only sender can delete their message
    if (message.senderId !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this message'
      });
    }

    // Delete the message
    await Message.findByIdAndDelete(messageId);

    // Broadcast deletion to receiver
    broadcastToUser(message.receiverId, 'message:deleted', {
      messageId,
      deletedBy: userId,
      timestamp: new Date()
    });

    res.status(200).json({
      success: true,
      message: 'Message deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting message:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete message',
      error: error.message
    });
  }
};

module.exports = {
  sendMessage,
  getChatHistory,
  markMessagesAsRead,
  getUnreadCount,
  getAllUnreadCounts,
  deleteMessage
};
