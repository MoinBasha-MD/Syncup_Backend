const User = require('../models/userModel');
const { generateToken } = require('../utils/generateToken');

/**
 * @desc    Register a new user
 * @route   POST /api/auth/register
 * @access  Public
 */
const registerUser = async (req, res) => {
  try {
    const { name, phoneNumber, email, password } = req.body;

    // Validate required fields
    if (!name || !phoneNumber || !email || !password) {
      return res.status(400).json({ 
        success: false,
        message: 'Please provide all required fields: name, phoneNumber, email, password' 
      });
    }

    // Check if user already exists with this email or phone
    const userExistsWithEmail = await User.findOne({ email });
    if (userExistsWithEmail) {
      return res.status(400).json({ 
        success: false,
        message: 'User with this email already exists' 
      });
    }

    const userExistsWithPhone = await User.findOne({ phoneNumber });
    if (userExistsWithPhone) {
      return res.status(400).json({ 
        success: false,
        message: 'User with this phone number already exists' 
      });
    }

    // Create user
    const user = await User.create({
      name,
      phoneNumber,
      email,
      password,
      status: 'available',
      customStatus: '',
      statusUntil: null
    });

    if (user) {
      // Generate token
      const token = generateToken(user._id, user.userId);
      
      res.status(201).json({
        success: true,
        data: {
          userId: user.userId,
          name: user.name,
          phoneNumber: user.phoneNumber,
          email: user.email,
          status: user.status,
          token
        }
      });
    } else {
      res.status(400).json({ 
        success: false,
        message: 'Invalid user data' 
      });
    }
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error during registration', 
      error: error.message 
    });
  }
};

/**
 * @desc    Login user and get token
 * @route   POST /api/auth/login
 * @access  Public
 */
const loginUser = async (req, res) => {
  try {
    const { phoneNumber, password } = req.body;

    // Validate required fields
    if (!phoneNumber || !password) {
      return res.status(400).json({ 
        success: false,
        message: 'Please provide both phoneNumber and password' 
      });
    }

    // Check for user with phone number
    const user = await User.findOne({ phoneNumber }).select('+password');

    if (!user) {
      return res.status(401).json({ 
        success: false,
        message: 'Invalid phone number or password' 
      });
    }

    // Check if password matches
    const isMatch = await user.matchPassword(password);

    if (!isMatch) {
      return res.status(401).json({ 
        success: false,
        message: 'Invalid phone number or password' 
      });
    }

    // Check if status timer has expired
    if (user.statusUntil && new Date() > new Date(user.statusUntil)) {
      user.status = 'available';
      user.customStatus = '';
      user.statusUntil = null;
      await user.save();
    }

    // Generate token
    const token = generateToken(user._id, user.userId);

    res.json({
      success: true,
      data: {
        userId: user.userId,
        name: user.name,
        phoneNumber: user.phoneNumber,
        email: user.email,
        status: user.status,
        customStatus: user.customStatus,
        statusUntil: user.statusUntil,
        token
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error during login', 
      error: error.message 
    });
  }
};

/**
 * @desc    Check if user exists by phone number
 * @route   POST /api/auth/check
 * @access  Public
 */
const checkUserExists = async (req, res) => {
  try {
    const { phoneNumber } = req.body;

    if (!phoneNumber) {
      return res.status(400).json({ 
        success: false,
        message: 'Please provide a phone number' 
      });
    }

    const user = await User.findOne({ phoneNumber }).select('userId name');

    res.json({
      success: true,
      exists: !!user,
      data: user ? {
        userId: user.userId,
        name: user.name
      } : null
    });
  } catch (error) {
    console.error('Check user error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error while checking user', 
      error: error.message 
    });
  }
};

module.exports = {
  registerUser,
  loginUser,
  checkUserExists
};
