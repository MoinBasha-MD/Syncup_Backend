const User = require('../models/userModel');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

// Configure storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../uploads/profile-images');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Create unique filename with original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, 'profile-' + uniqueSuffix + ext);
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  // Accept only image files
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed!'), false);
  }
};

// Configure upload
const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max file size
  },
  fileFilter: fileFilter
});

// Upload profile image
const uploadProfileImage = async (req, res) => {
  try {
    console.log('Upload controller - Request received');
    console.log('Upload controller - Authenticated user:', req.user?._id);
    console.log('Upload controller - Request body:', req.body);
    console.log('Upload controller - File:', req.file ? 'File uploaded' : 'No file');
    
    // req.file is the 'profileImage' file
    // req.body will hold the text fields, if there were any
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload a file'
      });
    }

    // Get userid from request body
    const { userid } = req.body;
    console.log('Upload controller - User ID from body:', userid);
    
    if (!userid) {
      // Delete the uploaded file if no user ID provided
      fs.unlinkSync(req.file.path);
      console.error('Upload controller - No userid provided in request body');
      return res.status(400).json({
        success: false,
        message: 'User ID is required'
      });
    }

    // Verify the authenticated user matches the requested user ID
    // This ensures users can only upload profile pictures for themselves
    if (req.user && req.user.userId && req.user.userId.toString() !== userid.toString()) {
      console.error(`Upload controller - User ID mismatch: ${req.user.userId} vs ${userid}`);
      fs.unlinkSync(req.file.path);
      return res.status(403).json({
        success: false,
        message: 'Not authorized to upload for this user'
      });
    }

    // Find user by UUID (userId field)
    console.log('Upload controller - Finding user with userId:', userid);
    const user = await User.findOne({ userId: userid });

    if (!user) {
      // Delete the uploaded file if user not found
      fs.unlinkSync(req.file.path);
      console.error('Upload controller - User not found with ID:', userid);
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    console.log('Upload controller - User found:', user._id);

    // If user already has a profile image, delete the old one
    if (user.profileImage && user.profileImage.startsWith('/uploads/')) {
      const oldImagePath = path.join(__dirname, '..', user.profileImage);
      if (fs.existsSync(oldImagePath)) {
        fs.unlinkSync(oldImagePath);
      }
    }

    // Update user profile with new image URL
    // Store the path relative to the server root
    const imageUrl = `/uploads/profile-images/${req.file.filename}`;
    user.profileImage = imageUrl;
    await user.save();

    res.status(200).json({
      success: true,
      data: {
        profileImage: imageUrl
      },
      message: 'Profile image uploaded successfully'
    });
  } catch (error) {
    console.error('Error uploading profile image:', error);
    // If there was an error and a file was uploaded, delete it
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({
      success: false,
      message: 'Error uploading profile image',
      error: error.message
    });
  }
};

module.exports = {
  uploadProfileImage,
  uploadMiddleware: upload.single('profileImage')
};
