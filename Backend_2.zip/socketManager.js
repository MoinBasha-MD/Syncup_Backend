const socketIO = require('socket.io');
const jwt = require('jsonwebtoken');
const User = require('./models/userModel');
const winston = require('winston');

// Configure logger for Socket.IO operations
const socketLogger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/socket.log' }),
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ],
});

// Map to store active user socket connections
const userSockets = new Map();
// Map to store user's contacts for quick lookup
const userContactsMap = new Map();
// Connection statistics
const connectionStats = {
  totalConnections: 0,
  activeConnections: 0,
  totalDisconnections: 0,
  authFailures: 0
};

/**
 * Initialize Socket.IO with the HTTP server
 * @param {Object} server - HTTP server instance
 */
const initializeSocketIO = (server) => {
  const io = socketIO(server, {
    // Production-optimized configuration
    cors: {
      origin: process.env.NODE_ENV === 'production' 
        ? process.env.ALLOWED_ORIGINS?.split(',') || false
        : '*',
      methods: ['GET', 'POST'],
      credentials: true
    },
    // Connection settings
    pingTimeout: 60000, // 60 seconds
    pingInterval: 25000, // 25 seconds
    upgradeTimeout: 10000, // 10 seconds
    maxHttpBufferSize: 1e6, // 1MB
    allowEIO3: true, // Allow Engine.IO v3 clients
    
    // Transport settings
    transports: ['websocket', 'polling'],
    allowUpgrades: true,
    
    // Compression
    compression: true,
    
    // Connection state recovery (Socket.IO v4.6+)
    connectionStateRecovery: {
      maxDisconnectionDuration: 2 * 60 * 1000, // 2 minutes
      skipMiddlewares: true,
    }
  });

  // Enhanced authentication middleware with rate limiting
  const authAttempts = new Map();
  
  io.use(async (socket, next) => {
    const clientIP = socket.handshake.address;
    const now = Date.now();
    
    // Rate limiting for auth attempts
    const attempts = authAttempts.get(clientIP) || { count: 0, resetTime: now + 60000 };
    
    if (now > attempts.resetTime) {
      attempts.count = 0;
      attempts.resetTime = now + 60000;
    }
    
    if (attempts.count >= 10) { // Max 10 attempts per minute
      connectionStats.authFailures++;
      return next(new Error('Too many authentication attempts. Please try again later.'));
    }
    
    attempts.count++;
    authAttempts.set(clientIP, attempts);
    
    try {
      const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.replace('Bearer ', '');
      
      if (!token) {
        connectionStats.authFailures++;
        return next(new Error('Authentication error: Token missing'));
      }
      
      // Verify JWT token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Get user from database with minimal fields
      const user = await User.findById(decoded.id).select('userId name isActive').lean();
      
      if (!user) {
        connectionStats.authFailures++;
        return next(new Error('Authentication error: User not found'));
      }
      
      // Check if user account is active
      if (user.isActive === false) {
        connectionStats.authFailures++;
        return next(new Error('Authentication error: Account deactivated'));
      }
      
      // Attach user to socket
      socket.user = {
        id: user._id,
        userId: user.userId,
        name: user.name
      };
      
      // Reset auth attempts on successful authentication
      authAttempts.delete(clientIP);
      
      next();
    } catch (error) {
      connectionStats.authFailures++;
      socketLogger.error('Socket authentication error:', {
        error: error.message,
        clientIP,
        userAgent: socket.handshake.headers['user-agent']
      });
      next(new Error('Authentication error: ' + error.message));
    }
  });

  // Connection handler with enhanced logging and management
  io.on('connection', async (socket) => {
    // Validate that socket.user exists (should be set by auth middleware)
    if (!socket.user || !socket.user.id) {
      socketLogger.error('Socket connection without proper authentication', {
        socketId: socket.id,
        clientIP: socket.handshake.address,
        userAgent: socket.handshake.headers['user-agent']
      });
      socket.disconnect(true);
      return;
    }
    
    const userId = socket.user.id.toString();
    connectionStats.totalConnections++;
    connectionStats.activeConnections++;
    
    socketLogger.info('User connected', {
      userId,
      userName: socket.user.name,
      socketId: socket.id,
      clientIP: socket.handshake.address,
      userAgent: socket.handshake.headers['user-agent'],
      transport: socket.conn.transport.name,
      totalActive: connectionStats.activeConnections
    });
    
    // Handle multiple connections from same user
    const existingSocket = userSockets.get(userId);
    if (existingSocket && existingSocket.connected) {
      socketLogger.warn('Multiple connections detected for user', { userId });
      existingSocket.emit('force_disconnect', { reason: 'New connection established' });
      existingSocket.disconnect(true);
    }
    
    // Store user's socket connection
    userSockets.set(userId, socket);
    
    try {
      // Fetch and cache user's contacts for quick lookup
      console.log(`🔍 Attempting to fetch contacts for user ID: ${userId}`);
      console.log(`🔍 User ID type: ${typeof userId}, length: ${userId.length}`);
      
      const user = await User.findById(userId);
      console.log(`🔍 Database query result:`, {
        userFound: !!user,
        userName: user?.name,
        userUserId: user?.userId,
        contactsArray: user?.contacts,
        contactsLength: user?.contacts?.length || 0
      });
      
      if (user && user.contacts && user.contacts.length > 0) {
        const contactIds = user.contacts.map(id => id.toString());
        userContactsMap.set(userId, new Set(contactIds));
        console.log(`✅ Successfully cached ${contactIds.length} contacts for user ${userId}:`, contactIds);
        
        // Also log the actual contact details for debugging
        const contactDetails = await User.find(
          { _id: { $in: user.contacts } },
          'name phoneNumber userId'
        );
        console.log(`📞 Contact details:`, contactDetails.map(c => ({
          name: c.name,
          phone: c.phoneNumber,
          id: c._id.toString()
        })));
      } else {
        console.log(`⚠️ User ${userId} has no contacts to cache - Reasons:`);
        console.log(`   - User found: ${!!user}`);
        console.log(`   - User has contacts array: ${!!(user && user.contacts)}`);
        console.log(`   - Contacts array length: ${user?.contacts?.length || 0}`);
        userContactsMap.set(userId, new Set()); // Set empty set to avoid undefined
      }
      
      // Send initial status of all contacts to the user
      if (user && user.contacts && user.contacts.length > 0) {
        const contacts = await User.find(
          { _id: { $in: user.contacts } },
          'userId name status customStatus statusUntil'
        );
        
        if (contacts.length > 0) {
          socket.emit('contacts_status_initial', contacts.map(contact => ({
            contactId: contact._id,
            userId: contact.userId,
            name: contact.name,
            status: contact.status,
            customStatus: contact.customStatus,
            statusUntil: contact.statusUntil
          })));
        }
      }
    } catch (error) {
      console.error('Error caching user contacts:', error);
    }
    
    // Handle disconnection with detailed logging
    socket.on('disconnect', (reason) => {
      connectionStats.activeConnections--;
      connectionStats.totalDisconnections++;
      
      socketLogger.info('User disconnected', {
        userId,
        userName: socket.user.name,
        socketId: socket.id,
        reason,
        duration: Date.now() - socket.handshake.time,
        totalActive: connectionStats.activeConnections
      });
      
      userSockets.delete(userId);
      userContactsMap.delete(userId);
    });
    
    // Handle connection errors
    socket.on('error', (error) => {
      socketLogger.error('Socket error', {
        userId,
        socketId: socket.id,
        error: error.message,
        stack: error.stack
      });
    });
    
    // Handle transport changes
    socket.conn.on('upgrade', () => {
      socketLogger.info('Transport upgraded', {
        userId,
        socketId: socket.id,
        transport: socket.conn.transport.name
      });
    });
    
    // Handle contact list update
    socket.on('update_contacts', async () => {
      try {
        // Refresh contacts cache when user updates their contacts
        const user = await User.findById(userId);
        if (user && user.contacts) {
          userContactsMap.set(userId, new Set(user.contacts.map(id => id.toString())));
        }
      } catch (error) {
        console.error('Error updating contacts cache:', error);
      }
    });
    
    // 💬 CHAT FEATURES: Typing Indicators
    socket.on('typing_start', (data) => {
      console.log(`✍️ User ${socket.user.name} started typing to ${data.receiverId}`);
      
      // Broadcast typing indicator to the receiver
      const receiverSocket = userSockets.get(data.receiverId.toString());
      if (receiverSocket && receiverSocket.connected) {
        receiverSocket.emit('typing:start', {
          userId: socket.user.userId,
          senderId: userId,
          name: socket.user.name,
          timestamp: new Date().toISOString()
        });
        console.log(`📤 Typing start broadcasted to ${data.receiverId}`);
      } else {
        console.log(`❌ Receiver ${data.receiverId} not found or offline`);
      }
    });
    
    socket.on('typing_stop', (data) => {
      console.log(`⏹️ User ${socket.user.name} stopped typing to ${data.receiverId}`);
      
      // Broadcast typing stop to the receiver
      const receiverSocket = userSockets.get(data.receiverId.toString());
      if (receiverSocket && receiverSocket.connected) {
        receiverSocket.emit('typing:stop', {
          userId: socket.user.userId,
          senderId: userId,
          name: socket.user.name,
          timestamp: new Date().toISOString()
        });
        console.log(`📤 Typing stop broadcasted to ${data.receiverId}`);
      } else {
        console.log(`❌ Receiver ${data.receiverId} not found or offline`);
      }
    });
    
    // 💬 CHAT FEATURES: New Message Notifications
    socket.on('message:send', (messageData) => {
      console.log(`📨 Broadcasting new message from ${socket.user.name}`);
      
      // Broadcast to receiver
      const receiverSocket = userSockets.get(messageData.receiverId.toString());
      if (receiverSocket && receiverSocket.connected) {
        receiverSocket.emit('message:new', {
          ...messageData,
          senderName: socket.user.name,
          timestamp: new Date().toISOString()
        });
        console.log(`📤 Message broadcasted to ${messageData.receiverId}`);
      } else {
        console.log(`❌ Message receiver ${messageData.receiverId} not found or offline`);
      }
    });
    
    // 💬 CHAT FEATURES: Message Status Updates
    socket.on('message:delivered', (data) => {
      console.log(`✅ Message ${data.messageId} delivered`);
      
      // Notify sender that message was delivered
      const senderSocket = userSockets.get(data.senderId.toString());
      if (senderSocket && senderSocket.connected) {
        senderSocket.emit('message:delivered', {
          messageId: data.messageId,
          timestamp: new Date().toISOString()
        });
      }
    });
    
    socket.on('message:read', (data) => {
      console.log(`👁️ Message ${data.messageId} read`);
      
      // Notify sender that message was read
      const senderSocket = userSockets.get(data.senderId.toString());
      if (senderSocket && senderSocket.connected) {
        senderSocket.emit('message:read', {
          messageId: data.messageId,
          readBy: userId,
          timestamp: new Date().toISOString()
        });
      }
    });
  });

  // Periodic cleanup and statistics logging
  setInterval(() => {
    // Clean up stale auth attempts
    const now = Date.now();
    for (const [ip, attempts] of authAttempts.entries()) {
      if (now > attempts.resetTime) {
        authAttempts.delete(ip);
      }
    }
    
    // Log connection statistics (only in development)
    if (process.env.NODE_ENV !== 'production') {
      socketLogger.info('Connection Statistics', connectionStats);
    }
  }, 300000); // Every 5 minutes
  
  // Graceful shutdown handler
  const gracefulShutdown = () => {
    socketLogger.info('Shutting down Socket.IO server...');
    
    // Notify all connected clients
    io.emit('server_shutdown', { message: 'Server is shutting down for maintenance' });
    
    // Close all connections
    io.close(() => {
      socketLogger.info('Socket.IO server closed');
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  socketLogger.info('Socket.IO initialized', {
    transports: ['websocket', 'polling'],
    cors: process.env.NODE_ENV === 'production' ? 'restricted' : 'open',
    compression: true
  });
  
  return io;
};

/**
 * Broadcast a message/event to a specific user by their userId
 * @param {string} userId - User ID to broadcast to
 * @param {string} event - Event name to emit
 * @param {Object} data - Data to send with the event
 */
const broadcastToUser = (userId, event, data) => {
  try {
    const userIdString = userId.toString();
    const socket = userSockets.get(userIdString);
    
    if (socket && socket.connected) {
      console.log(`📨 Broadcasting ${event} to user ${userIdString}`);
      socket.emit(event, data);
      return true;
    } else {
      console.log(`❌ User ${userIdString} socket not found or disconnected for event ${event}`);
      return false;
    }
  } catch (error) {
    console.error('❌ Error broadcasting to user:', error);
    return false;
  }
};

/**
 * Broadcast status update to all users who have this user in their contacts
 * @param {Object} user - User who updated their status
 * @param {Object} statusData - New status data
 */
const broadcastStatusUpdate = async (user, statusData) => {
  try {
    const userIdString = user._id.toString();
    
    console.log(`🔍 Finding users to notify for status update from ${user.name} (${userIdString})`);
    console.log(`📊 Current userContactsMap has ${userContactsMap.size} entries`);
    console.log(`🔌 Current userSockets has ${userSockets.size} connected users`);
    
    // Use cached contacts if available for better performance
    let usersToNotify = [];
    
    // Find all users who have this user in their contacts
    for (const [recipientId, contacts] of userContactsMap.entries()) {
      console.log(`🔍 Checking user ${recipientId} with ${contacts.size} contacts`);
      if (contacts.has(userIdString)) {
        console.log(`✅ User ${recipientId} has ${userIdString} in their contacts`);
        usersToNotify.push(recipientId);
      }
    }
    
    console.log(`📋 Found ${usersToNotify.length} users from cache`);
    
    // Always also check database to ensure we don't miss anyone
    // (in case cache is incomplete or stale)
    try {
      console.log(`🔍 Querying database for users who have ${userIdString} in their contacts...`);
      
      const dbUsers = await User.find({ contacts: user._id }, '_id name phoneNumber contacts');
      console.log(`🔍 Database query: User.find({ contacts: ${user._id} })`);
      console.log(`🔍 Raw database results:`, dbUsers.map(u => ({
        id: u._id.toString(),
        name: u.name,
        phone: u.phoneNumber,
        contactsCount: u.contacts?.length || 0,
        hasTargetUser: u.contacts?.some(c => c.toString() === userIdString)
      })));
      
      const dbUserIds = dbUsers.map(u => u._id.toString());
      
      console.log(`📋 Found ${dbUserIds.length} users from database:`, dbUserIds);
      
      // Also check if there are any users in the database at all
      const totalUsers = await User.countDocuments({});
      const usersWithContacts = await User.countDocuments({ contacts: { $exists: true, $ne: [] } });
      console.log(`📊 Database stats: Total users: ${totalUsers}, Users with contacts: ${usersWithContacts}`);
      
      // Merge cache results with database results (remove duplicates)
      const allUsersToNotify = [...new Set([...usersToNotify, ...dbUserIds])];
      usersToNotify = allUsersToNotify;
      
      console.log(`📋 Total unique users to notify: ${usersToNotify.length}`);
    } catch (dbError) {
      console.error('❌ Error querying database for contacts:', dbError);
      // Continue with cache results if database query fails
    }
    
    console.log(`📢 Broadcasting status update for ${user.name} to ${usersToNotify.length} users`);
    
    // Broadcast to each user who has this contact
    let successfulBroadcasts = 0;
    usersToNotify.forEach(recipientId => {
      const socket = userSockets.get(recipientId);
      
      if (socket && socket.connected) {
        console.log(`✅ Emitting status update to connected user ${recipientId}`);
        socket.emit('contact_status_update', {
          contactId: user._id,
          userId: user.userId,
          phoneNumber: user.phoneNumber, // Add phone number for better matching
          name: user.name,
          status: statusData.status,
          customStatus: statusData.customStatus,
          statusUntil: statusData.statusUntil,
          timestamp: new Date().toISOString()
        });
        successfulBroadcasts++;
      } else {
        console.log(`❌ User ${recipientId} socket not found or disconnected`);
      }
    });
    
    console.log(`📊 Successfully broadcast to ${successfulBroadcasts}/${usersToNotify.length} users`);
    
  } catch (error) {
    console.error('❌ Error broadcasting status update:', error);
  }
};

/**
 * Update a user's contacts cache when they add or remove contacts
 * @param {string} userId - MongoDB ObjectId of the user
 */
const refreshUserContacts = async (userId) => {
  try {
    const userIdString = userId.toString();
    if (!userSockets.has(userIdString)) {
      return; // User not connected, no need to update cache
    }
    
    const user = await User.findById(userId);
    if (user && user.contacts) {
      userContactsMap.set(userIdString, new Set(user.contacts.map(id => id.toString())));
      console.log(`Refreshed contacts cache for user ${userIdString}`);
    }
  } catch (error) {
    console.error('Error refreshing user contacts cache:', error);
  }
};

module.exports = {
  initializeSocketIO,
  broadcastStatusUpdate,
  broadcastToUser,
  refreshUserContacts
};
