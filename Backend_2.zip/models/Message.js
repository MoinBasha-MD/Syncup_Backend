const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  senderId: {
    type: String,
    required: true,
    index: true
  },
  receiverId: {
    type: String,
    required: true,
    index: true
  },
  message: {
    type: String,
    required: true
  },
  messageType: {
    type: String,
    enum: ['text', 'image', 'file', 'audio', 'video'],
    default: 'text'
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  status: {
    type: String,
    enum: ['sent', 'delivered', 'read'],
    default: 'sent'
  },
  replyTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message',
    default: null
  },
  attachments: [{
    type: String,
    url: String,
    size: Number,
    mimeType: String
  }]
}, {
  timestamps: true
});

// Compound indexes for efficient querying
messageSchema.index({ senderId: 1, receiverId: 1, timestamp: -1 });
messageSchema.index({ receiverId: 1, senderId: 1, timestamp: -1 });
messageSchema.index({ receiverId: 1, status: 1 });

// Static method to get conversation between two users
messageSchema.statics.getConversation = async function(userId1, userId2, skip = 0, limit = 50) {
  return this.find({
    $or: [
      { senderId: userId1, receiverId: userId2 },
      { senderId: userId2, receiverId: userId1 }
    ]
  })
  .sort({ timestamp: -1 })
  .skip(skip)
  .limit(limit)
  .lean();
};

// Static method to mark messages as read
messageSchema.statics.markAsRead = async function(senderId, receiverId) {
  return this.updateMany(
    {
      senderId: senderId,
      receiverId: receiverId,
      status: { $ne: 'read' }
    },
    {
      $set: { status: 'read' }
    }
  );
};

// Static method to get unread count from a specific sender
messageSchema.statics.getUnreadCount = async function(senderId, receiverId) {
  return this.countDocuments({
    senderId: senderId,
    receiverId: receiverId,
    status: { $ne: 'read' }
  });
};

// Static method to get all unread counts for a user
messageSchema.statics.getAllUnreadCounts = async function(userId) {
  const pipeline = [
    {
      $match: {
        receiverId: userId,
        status: { $ne: 'read' }
      }
    },
    {
      $group: {
        _id: '$senderId',
        count: { $sum: 1 },
        lastMessage: { $max: '$timestamp' }
      }
    },
    {
      $project: {
        senderId: '$_id',
        count: 1,
        lastMessage: 1,
        _id: 0
      }
    }
  ];

  return this.aggregate(pipeline);
};

const Message = mongoose.model('Message', messageSchema);

module.exports = Message;
